﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sem3
{   //intr-o interfata definim doar prototipuri de functii, implementate in clasa care implementeaza interfata
    //INTERFATA NU CONTINE ATRIBUTE, CONSTRUCTORI
    interface IMedia
    {
        float calculeazaMedia();
    }
}
