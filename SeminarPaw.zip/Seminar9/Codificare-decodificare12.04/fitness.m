function [valoare] = fitness(x,mesaj,cod,n)
val=0;
for i=1:n
    ind=find(x==cod(i));
    val=val+abs(double(mesaj(i))-double(ind));
end
valoare=1.0/(double(val)+1);
end

